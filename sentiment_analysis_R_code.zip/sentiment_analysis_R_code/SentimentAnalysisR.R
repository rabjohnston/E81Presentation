# Haris Memic and Rob Johnston

# Here we extended Udemy’s “Text Mining, Scraping and Sentiment Analysis with R”
# implementation of sentiment scoring function. The function was modified to handle negations.
# Thus "He is not nice" is scored as a -1 sentiment, "He is nice" is scored as a +1
# To accomplish negation we modified "Bing Liu's Lexicon", which we extended to adjust for negations.
# The original non-modified version of the lexicon can be found at:
# https://www.cs.uic.edu/~liub/FBS/sentiment-analysis.html#lexicon 

score.sentiment = function(sentences, pos.words, neg.words, .progress="none")
{
  # sentences: vector of text to score
  
  # creating simple array of score with laply
  scores = laply(sentences,
                 function(sentence, pos.words, neg.words)
                 {
                   # remove punctuation - using global substitutes
                   sentence = gsub("[[:punct:]]", "", sentence)
                   # remove control characters
                   sentence = gsub("[[:cntrl:]]", "", sentence)
                   # remove digits
                   sentence = gsub("\\d+", "", sentence)
                   
                   tryTolower = function(x)
                   {
                     y = NA
                     try_error = tryCatch(tolower(x), error=function(e) e)
                     if (!inherits(try_error, "error"))
                       y = tolower(x)
                     return(y)
                   }
                   
                   # convert all text to lowercase
                   sentence = sapply(sentence, tryTolower)
                   
                   # form negation compound-words
                   sentence = gsub("not ", "not_", sentence)
                   sentence = gsub("no ", "not_", sentence)
                   
                   # split sentence into words with str_split (stringr package)
                   word.list = str_split(sentence, "\\s+")
                   # unlist a list of vectors into a single vector
                   words = unlist(word.list)
                   words 
                   cat(" Word count:", length(words))
                   cat(" Text:",words)
                   
                   # compare words to "not_" modified dictionaries 
                   pos.matches = match (words, pos.words)
                   neg.matches = match (words, neg.words)
                   
                   # get the position of the matched term or NA
                   # we just want a TRUE/FALSE
                   pos.matches = !is.na(pos.matches)
                   neg.matches = !is.na(neg.matches)
                   cat(" Pos.matches:", sum(pos.matches))
                   cat(" Neg.maches:", sum(neg.matches))
                   
                   # final score
                   score = sum(pos.matches) - sum(neg.matches)

                   return(score)
                 }, pos.words, neg.words, .progress=.progress)
  
  # data frame with score for each text
  scores.df = data.frame(text=sentences, score=scores)
  return(scores.df)
}

############################################
#loding in the dictionary
setwd("lexicon") # directory where dictionary is stored
library("stringr")
library("plyr")
#dictionary files
positive = readLines("positive-words.txt")
negative = readLines("negative-words.txt")

#test to see if sentiment analysis works
mytest = c("first text is great", "The second text is bad and more bad", 
           "This third is not bad"
           )
testsentiment = score.sentiment(mytest, positive, negative)
class (testsentiment)
testsentiment
testsentiment$score
